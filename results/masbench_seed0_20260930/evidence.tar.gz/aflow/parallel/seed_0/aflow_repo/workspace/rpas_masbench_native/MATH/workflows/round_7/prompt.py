VERIFIER_PROMPT = """
You are a strict format verifier. 
Input Parsed Answer: {input}
Input Problem: {problem}

Task:
1. Check if the answer contains `<<horizon>>` if multiple values are expected, or is a single integer.
2. If the format is invalid, return "INVALID_FORMAT".
3. If valid, return the string as is.
"""