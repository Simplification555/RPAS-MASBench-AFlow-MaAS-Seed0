XXX_PROMPT = """
You are an expert Python programmer. Your task is to write a Python script that solves the following math problem. The problem involves arithmetic in the field Z_23 (integers modulo 23). All additions, subtractions, multiplications, and intermediate results must be reduced modulo 23 to an integer from 0 through 22.

Problem:
{problem}

Requirements:
1. Write a complete Python script that defines the variables and equations based on the problem text.
2. Perform all calculations using Python's modulo operator (%) to ensure results are in Z_23.
3. The script must print the final answer(s) in the exact format required by the problem statement.
4. If there are multiple answers, join them using exactly `<<horizon>>`.
5. End the output with a line `FINAL ANSWER: ANSWER`.

Output the code and the execution result.
"""