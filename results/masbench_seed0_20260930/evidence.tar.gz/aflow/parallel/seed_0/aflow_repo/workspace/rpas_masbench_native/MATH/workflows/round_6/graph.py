from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_6.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.programmer = operator.Programmer(self.llm)
        self.refiner = operator.Custom(self.llm)  # Added Refiner
        self.verifier = operator.Custom(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)

    async def __call__(self, problem: str):
        """
        Optimized Workflow: Generate -> Refine -> Verify -> Ensemble
        """
        # Step 1: Generate Python code to solve the problem
        code_result = await self.programmer(problem=problem, analysis="None")
        raw_output = code_result['output']
        
        # Step 2: Refine the output to ensure strict formatting
        # This removes markdown, ensures "FINAL ANSWER:" exists, and cleans up noise
        refinement_prompt = f"""
        Input Raw Output: {raw_output}
        Input Problem: {problem}
        
        Task:
        1. Extract ONLY the final answer line.
        2. Ensure the line starts exactly with "FINAL ANSWER: ".
        3. If the answer contains multiple values, ensure they are separated by "<<horizon>>".
        4. If the format is incorrect, reconstruct the correct format based on the problem logic.
        5. Return ONLY the corrected string "FINAL ANSWER: <cleaned_answer>".
        """
        refined_result = await self.refiner(input=refinement_prompt, instruction="")
        refined_output = refined_result['response']
        
        # Step 3: Verify the refined output against the problem constraints
        verification_prompt = f"""
        You are a strict format verifier. 
        Input Refined Output: {refined_output}
        Input Problem: {problem}
        
        Task:
        1. Check if the output starts exactly with "FINAL ANSWER: ".
        2. Extract the content after the colon.
        3. Verify if the content is a valid integer sequence (separated by <<horizon>> or single integer).
        4. If valid, return the extracted string.
        5. If invalid, return "INVALID_FORMAT".
        """
        verification_result = await self.verifier(input=verification_prompt, instruction="")
        verified_output = verification_result['response']
        
        # Step 4: Generate multiple variations for Ensemble
        solutions = []
        solutions.append(verified_output)  # Include the verified/refined result
        
        for i in range(2):
            varied_instruction = f"Solve the problem using Python. Ensure all calculations are modulo 23. Output strictly in format: FINAL ANSWER: <answer> separated by <<horizon>> if multiple."
            res = await self.custom(input=problem, instruction=varied_instruction)
            solutions.append(res['response'])
        
        # Step 5: Ensemble the solutions
        final_result = await self.sc_ensemble(solutions=solutions, problem=problem)
        
        return final_result['response'], self.llm.get_usage_summary()["total_cost"]
