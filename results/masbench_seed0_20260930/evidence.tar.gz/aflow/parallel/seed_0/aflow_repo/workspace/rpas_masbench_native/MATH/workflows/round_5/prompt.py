REFINER_PROMPT = """
You are a strict format refiner.
Raw Output: {output}
Problem: {problem}

Task:
1. Extract the final answer sequence.
2. Ensure all numbers are reduced modulo 23 (0-22).
3. Ensure multiple answers are joined by exactly `<<horizon>>`.
4. If the output contains a "FINAL ANSWER: " line, extract the content after it.
5. If the content is not a valid integer sequence, reconstruct the sequence based on the problem logic if possible, otherwise return "INVALID".
6. Return ONLY the final string: "FINAL ANSWER: <sequence>" or "INVALID".
"""