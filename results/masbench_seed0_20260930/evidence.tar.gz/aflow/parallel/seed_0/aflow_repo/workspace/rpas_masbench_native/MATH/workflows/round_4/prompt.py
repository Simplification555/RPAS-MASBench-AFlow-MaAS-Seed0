VERIFIER_PROMPT = """
You are a strict format verifier. 
Input Code Output: {output}
Input Problem: {problem}

Task:
1. Check if the output contains a line starting with "FINAL ANSWER: ".
2. If yes, extract the content after the colon.
3. If the content is not a valid integer sequence (separated by <<horizon>> or single integer), return "INVALID_FORMAT".
4. If the content is valid, return the extracted string.
"""