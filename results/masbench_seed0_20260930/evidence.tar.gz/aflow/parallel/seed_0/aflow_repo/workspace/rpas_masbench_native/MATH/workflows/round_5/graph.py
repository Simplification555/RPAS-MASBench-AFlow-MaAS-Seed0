from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_5.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.programmer = operator.Programmer(self.llm)
        self.custom = operator.Custom(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)
        self.refiner = operator.Custom(self.llm)  # Added Refiner

    async def __call__(self, problem: str):
        """
        Optimized Workflow: Code Generation -> Execution -> Format Refinement -> Ensemble
        """
        # Step 1: Generate Python code to solve the problem
        code_result = await self.programmer(problem=problem, analysis="None")
        code = code_result['code']
        output = code_result['output']
        
        # Step 2: Refine the output format to ensure strict compliance
        # This step catches missing separators, wrong modulo, or missing "FINAL ANSWER" lines
        refinement_prompt = f"""
        You are a strict format refiner.
        Raw Output: {output}
        Problem: {problem}
        
        Task:
        1. Extract the final answer sequence.
        2. Ensure all numbers are reduced modulo 23 (0-22).
        3. Ensure multiple answers are joined by exactly `<<horizon>>`.
        4. If the output contains a "FINAL ANSWER: " line, extract the content after it.
        5. If the content is not a valid integer sequence, reconstruct the sequence based on the problem logic if possible, otherwise return "INVALID".
        6. Return ONLY the final string: "FINAL ANSWER: <sequence>" or "INVALID".
        """
        refined_result = await self.refiner(input=refinement_prompt, instruction="")
        refined_output = refined_result['response']
        
        # Step 3: Generate multiple variations to ensure robustness (Self-consistency)
        solutions = []
        for i in range(3):
            varied_instruction = f"Analyze the problem {i+1} times and solve it using Python code. Ensure all calculations are modulo 23. Output strictly in format: FINAL ANSWER: <answer>"
            res = await self.custom(input=problem, instruction=varied_instruction)
            solutions.append(res['response'])
        
        # Step 4: Ensemble the solutions to pick the most frequent correct answer
        final_result = await self.sc_ensemble(solutions=solutions, problem=problem)
        
        return final_result['response'], self.llm.get_usage_summary()["total_cost"]
