VERIFIER_PROMPT = """
You are a strict format verifier. 
Input Refined Output: {output}
Input Problem: {problem}

Task:
1. Check if the output starts exactly with "FINAL ANSWER: ".
2. Extract the content after the colon.
3. Verify if the content is a valid integer sequence (separated by <<horizon>> or single integer).
4. If valid, return the extracted string.
5. If invalid, return "INVALID_FORMAT".
"""