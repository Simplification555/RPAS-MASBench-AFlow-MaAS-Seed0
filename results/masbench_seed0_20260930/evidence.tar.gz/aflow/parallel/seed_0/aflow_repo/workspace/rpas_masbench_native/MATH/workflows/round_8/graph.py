from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_8.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.programmer = operator.Programmer(self.llm)
        self.parser = operator.Custom(self.llm)  # Added Parser
        self.verifier = operator.Custom(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)

    async def __call__(self, problem: str):
        """
        Optimized Workflow: Code Generation -> Parse -> Verify -> Ensemble -> Format
        """
        # Step 1: Generate Python code to solve the problem
        code_result = await self.programmer(problem=problem, analysis="None")
        code = code_result['code']
        output = code_result['output']
        
        # Step 2: Parse the raw output to extract the clean answer string
        # This handles cases where the model outputs markdown or extra text
        parse_prompt = f"""
        Input Code Output: {output}
        Input Problem: {problem}
        
        Task:
        1. Extract the final answer string.
        2. If the output contains "FINAL ANSWER: ", extract the content after the colon.
        3. If the output contains "Problem 1: ... Problem 2: ...", extract the sequence of numbers joined by <<horizon>>.
        4. Return ONLY the extracted string (e.g., "19<<horizon>>16" or "9<<horizon>>1").
        """
        parse_result = await self.parser(input=parse_prompt, instruction="")
        parsed_answer = parse_result['response']
        
        # Step 3: Verify the format of the parsed answer
        verification_prompt = f"""
        You are a strict format verifier. 
        Input Answer String: {parsed_answer}
        Input Problem: {problem}
        
        Task:
        1. Check if the string contains valid integers separated by `<<horizon>>` or is a single integer.
        2. If valid, return the string as is.
        3. If invalid (e.g., contains text, wrong separators), return "INVALID_FORMAT".
        """
        verification_result = await self.verifier(input=verification_prompt, instruction="")
        verified_output = verification_result['response']
        
        # Step 4: Generate multiple variations to ensure robustness (Self-consistency)
        solutions = []
        for i in range(3):
            varied_instruction = f"Solve the problem using Python code. Ensure all calculations are modulo 23. Output strictly in format: FINAL ANSWER: <answer>"
            res = await self.custom(input=problem, instruction=varied_instruction)
            # Parse the variation immediately to ensure clean input for ensemble
            var_parse_prompt = f"Input Code Output: {res['response']}\nInput Problem: {problem}\nTask: Extract the content after 'FINAL ANSWER: ' or the sequence of numbers. Return ONLY the string."
            var_parsed = await self.parser(input=var_parse_prompt, instruction="")
            solutions.append(var_parsed['response'])
        
        # Step 5: Ensemble the solutions to pick the most frequent correct answer
        final_result = await self.sc_ensemble(solutions=solutions, problem=problem)
        ensemble_answer = final_result['response']
        
        # Step 6: Format the final output strictly as required
        final_formatted = f"FINAL ANSWER: {ensemble_answer}"
        
        return final_formatted, self.llm.get_usage_summary()["total_cost"]
