from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_3.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.programmer = operator.Programmer(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)

    async def __call__(self, problem: str):
        """
        Implementation of the workflow
        """
        # Step 1: Generate Python code to solve the problem
        code_result = await self.programmer(problem=problem, analysis="None")
        code = code_result['code']
        output = code_result['output']
        
        # Step 2: Execute the code to get the precise numerical answer
        # The programmer node executes the code and returns the output
        # We assume the programmer node handles execution internally or we execute it here if needed.
        # Based on operator description: "Automatically writes, executes Python code, and returns the solution"
        # So 'output' in code_result should be the final answer string.
        
        # Step 3: Generate multiple variations to ensure robustness (Self-consistency)
        # We generate 3 different reasoning paths
        solutions = []
        for i in range(3):
            # Slightly vary the instruction to get diverse reasoning
            varied_instruction = f"Analyze the problem {i+1} times and solve it using Python code. Ensure all calculations are modulo 23."
            res = await self.custom(input=problem, instruction=varied_instruction)
            solutions.append(res['response'])
        
        # Step 4: Ensemble the solutions to pick the most frequent correct answer
        final_result = await self.sc_ensemble(solutions=solutions, problem=problem)
        
        return final_result['response'], self.llm.get_usage_summary()["total_cost"]
