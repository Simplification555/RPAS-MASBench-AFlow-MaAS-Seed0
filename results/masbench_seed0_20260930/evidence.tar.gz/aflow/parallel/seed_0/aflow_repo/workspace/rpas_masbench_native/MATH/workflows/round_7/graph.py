from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_7.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.programmer = operator.Programmer(self.llm)
        self.parser = operator.Custom(self.llm)  # Added Parser
        self.verifier = operator.Custom(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)

    async def __call__(self, problem: str):
        """
        Optimized Workflow: Code Generation -> Parse Answer -> Verify Format -> Ensemble
        """
        # Step 1: Generate Python code to solve the problem
        code_result = await self.programmer(problem=problem, analysis="None")
        code_output = code_result['output']
        
        # Step 2: Parse the raw output to extract the clean numerical answer
        # This handles cases where the code prints extra text or the answer is in a variable
        parse_prompt = f"""
        Input Code Output: {code_output}
        Input Problem: {problem}
        
        Task:
        1. Identify the final numerical answer(s) from the output.
        2. If multiple answers exist, join them with `<<horizon>>`.
        3. If no answer is found, return "NOT_FOUND".
        4. Return ONLY the extracted string (e.g., "10<<horizon>>16").
        """
        parsed_result = await self.parser(input=parse_prompt, instruction="")
        parsed_answer = parsed_result['response']
        
        # Step 3: Verify the output format using a custom verifier
        # This ensures the answer is in the correct format before ensemble
        verification_prompt = f"""
        You are a strict format verifier. 
        Input Parsed Answer: {parsed_answer}
        Input Problem: {problem}
        
        Task:
        1. Check if the answer contains `<<horizon>>` if multiple values are expected, or is a single integer.
        2. If the format is invalid, return "INVALID_FORMAT".
        3. If valid, return the string as is.
        """
        verification_result = await self.verifier(input=verification_prompt, instruction="")
        verified_output = verification_result['response']
        
        # Step 4: Generate multiple variations to ensure robustness (Self-consistency)
        solutions = []
        for i in range(3):
            varied_instruction = f"Analyze the problem {i+1} times and solve it using Python code. Ensure all calculations are modulo 23. Output strictly in format: FINAL ANSWER: <answer>"
            res = await self.custom(input=problem, instruction=varied_instruction)
            solutions.append(res['response'])
        
        # Step 5: Ensemble the solutions to pick the most frequent correct answer
        # Include the verified parsed answer as a high-confidence solution
        final_result = await self.sc_ensemble(solutions=solutions + [verified_output], problem=problem)
        
        return final_result['response'], self.llm.get_usage_summary()["total_cost"]
