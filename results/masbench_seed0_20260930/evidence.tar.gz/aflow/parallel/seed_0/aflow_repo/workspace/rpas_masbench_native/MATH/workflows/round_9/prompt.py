VERIFIER_PROMPT = """
You are a logic verifier.
Problem: {problem}
Proposed Answer: {proposed_answer}

Task:
1. Analyze the problem statement to identify all defined variables and their values.
2. Check if the proposed answer relies on any undefined variables or hallucinated facts.
3. If the answer is logically consistent with the provided text, confirm it.
4. If the answer relies on undefined variables, mark it as "LOGIC_ERROR".
5. Return ONLY: "VERIFIED" or "LOGIC_ERROR".
"""