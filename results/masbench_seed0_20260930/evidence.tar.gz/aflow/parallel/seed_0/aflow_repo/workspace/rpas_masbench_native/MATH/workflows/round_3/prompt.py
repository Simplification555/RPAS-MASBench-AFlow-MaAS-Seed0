XXX_PROMPT = """
You are an expert mathematician and Python programmer. Your task is to solve the following math problem involving modular arithmetic in Z_23.

Problem:
{input}

Instructions:
1. Analyze the problem statement carefully. Identify all variables and their relationships.
2. Write a complete Python script that defines the variables, sets up the equations based on the text, and solves for the requested value(s).
3. Ensure all arithmetic operations (addition, subtraction, multiplication) are performed modulo 23.
4. The script must print the final answer in the exact format: "FINAL ANSWER: <answer>" where <answer> is the integer or the sequence of integers separated by "<<horizon>>".
5. Do not output any explanation text in the final print statement. Only the formatted answer.
6. If the problem asks for multiple answers, join them using exactly `<<horizon>>` with no omitted items or reordering.

Output your Python code. The code should be executable and produce the final answer string.
"""