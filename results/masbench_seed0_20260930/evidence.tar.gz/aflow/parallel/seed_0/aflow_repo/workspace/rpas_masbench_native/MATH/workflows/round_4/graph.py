from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_4.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.programmer = operator.Programmer(self.llm)
        self.custom = operator.Custom(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)
        self.verifier = operator.Custom(self.llm)  # Added Verifier

    async def __call__(self, problem: str):
        """
        Optimized Workflow: Code Generation -> Execution -> Format Verification -> Ensemble
        """
        # Step 1: Generate Python code to solve the problem
        code_result = await self.programmer(problem=problem, analysis="None")
        code = code_result['code']
        output = code_result['output']
        
        # Step 2: Execute the code to get the precise numerical answer
        # The programmer node executes the code and returns the output
        # We assume the programmer node handles execution internally.
        
        # Step 3: Verify the output format and content using a custom verifier
        # This ensures the answer is in the correct format (e.g., "FINAL ANSWER: X")
        verification_prompt = f"""
        You are a strict format verifier. 
        Input Code Output: {output}
        Input Problem: {problem}
        
        Task:
        1. Check if the output contains a line starting with "FINAL ANSWER: ".
        2. If yes, extract the content after the colon.
        3. If the content is not a valid integer sequence (separated by <<horizon>> or single integer), return "INVALID_FORMAT".
        4. If the content is valid, return the extracted string.
        """
        verification_result = await self.custom(input=verification_prompt, instruction="")
        verified_output = verification_result['response']
        
        # Step 4: Generate multiple variations to ensure robustness (Self-consistency)
        solutions = []
        for i in range(3):
            # Slightly vary the instruction to get diverse reasoning
            varied_instruction = f"Analyze the problem {i+1} times and solve it using Python code. Ensure all calculations are modulo 23. Output strictly in format: FINAL ANSWER: <answer>"
            res = await self.custom(input=problem, instruction=varied_instruction)
            solutions.append(res['response'])
        
        # Step 5: Ensemble the solutions to pick the most frequent correct answer
        final_result = await self.sc_ensemble(solutions=solutions, problem=problem)
        
        return final_result['response'], self.llm.get_usage_summary()["total_cost"]
