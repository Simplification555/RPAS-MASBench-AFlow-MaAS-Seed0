VERIFIER_PROMPT = """
You are a strict format verifier. 
Input Answer String: {input}
Input Problem: {problem}

Task:
1. Check if the string contains valid integers separated by `<<horizon>>` or is a single integer.
2. If valid, return the string as is.
3. If invalid (e.g., contains text, wrong separators), return "INVALID_FORMAT".
"""