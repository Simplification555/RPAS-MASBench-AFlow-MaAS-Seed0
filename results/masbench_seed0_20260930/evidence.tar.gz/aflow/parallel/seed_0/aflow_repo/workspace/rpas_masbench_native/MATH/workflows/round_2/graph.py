from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_2.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.programmer = operator.Programmer(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)

    async def __call__(self, problem: str):
        """
        Implementation of the workflow
        """
        # Step 1: Generate Python code to solve the problem precisely
        code_solution = await self.programmer(problem=problem, analysis="Solve the problem using Python code with modulo 23 arithmetic.")
        
        # Step 2: Execute the code to get the result
        # Note: The Programmer operator returns a dict with 'code' and 'output'. 
        # We assume the 'output' contains the final calculated string.
        raw_output = code_solution['output']
        
        # Step 3: Use ScEnsemble to ensure robustness if multiple paths were taken or to re-verify
        # Here we pass the raw output as a single solution list for verification or re-generation if needed.
        # If the system supports generating multiple variations, we would pass a list.
        # For this structure, we use the ensemble to potentially re-run or validate the logic.
        final_solution = await self.sc_ensemble(solutions=[raw_output], problem=problem)
        
        return final_solution['response'], self.llm.get_usage_summary()["total_cost"]
