VALIDATOR_PROMPT = """
You are a strict format validator for math problem solutions.
Your task is to check if the provided solution string ends with exactly one line containing `FINAL ANSWER: <answer>`.
The `<answer>` part must contain only the final value(s) or a sequence joined by `<<horizon>>`.
If the format is correct, output ONLY the corrected string ending with `FINAL ANSWER: <answer>`.
If the format is incorrect (e.g., missing the prefix, wrong separator, tuple format), rewrite the string to strictly follow the format: `FINAL ANSWER: <corrected_answer>`.
Do not output any explanation, only the corrected string.

Input Solution:
{input}
"""