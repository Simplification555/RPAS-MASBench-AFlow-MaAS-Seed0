PARSER_PROMPT = """
You are a strict data extractor. Your task is to take the provided "Raw Ensemble Response" and extract the final answer sequence.

Rules:
1. The response may contain reasoning, code, or intermediate steps. You must ignore all of that.
2. Identify the final answer which is either a single integer (0-22) or a sequence of integers joined by exactly `<<horizon>>`.
3. If the response contains `FINAL ANSWER:`, extract the content after the colon.
4. If the response contains `\boxed{...}`, extract the content inside the box.
5. If the response contains a number at the very end of the text, use that.
6. Ensure the extracted string contains ONLY the answer (e.g., "2" or "2<<horizon>>13"). Do not include "FINAL ANSWER:", "\boxed", or any other text.
7. If the answer is a sequence, ensure no extra spaces surround the `<<horizon>>` separator.

Input Data:
Raw Ensemble Response: {raw_ensemble_response}

Output ONLY the extracted answer string.
"""

FORMATTER_PROMPT = """
You are a strict format validator. Your task is to take the provided "Parsed Answer" and ensure it strictly adheres to the required output format.

Required Format Rules:
1. The output must start with exactly `FINAL ANSWER: `.
2. The output must end with the answer immediately after the colon and space.
3. The answer part must be a single integer (0-22) or a sequence of integers joined by exactly `<<horizon>>`.
4. Do not include parentheses, tuples, or extra text.

Input Data:
Parsed Answer: {parsed_answer}

Output only the corrected string that starts with "FINAL ANSWER: " and ends with the answer. Do not include any other text.
"""