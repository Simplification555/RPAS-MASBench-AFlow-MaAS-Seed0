from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_5.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.programmer = operator.Programmer(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)
        self.validator = operator.Custom(self.llm)
        self.cost_manager = operator.CostManage(self.llm)

    async def __call__(self, problem: str):
        """
        Implementation of the workflow
        """
        # Step 1: Generate multiple independent solutions using the Programmer operator
        solutions = []
        for i in range(3):
            result = await self.programmer(problem=problem)
            if 'output' in result:
                solutions.append(result['output'])
            else:
                solutions.append(result.get('output', ''))

        # Step 2: Use ScEnsemble to select the most frequent solution
        final_result = await self.sc_ensemble(solutions=solutions, problem=problem)
        
        # Step 3: Validate the format of the final answer to ensure it matches 'FINAL ANSWER: <answer>'
        # This prevents extraction errors where the model outputs tuples or missing text
        validation_prompt = prompt_custom.VALIDATOR_PROMPT
        validation_response = await self.validator(input=final_result['response'], instruction=validation_prompt)
        
        # Step 4: Return the validated response and cost summary
        return validation_response['response'], self.llm.get_usage_summary()["total_cost"]
