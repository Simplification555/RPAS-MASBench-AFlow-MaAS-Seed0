from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_9.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.programmer = operator.Programmer(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)
        self.validator = operator.Custom(self.llm)
        self.reviewer = operator.Custom(self.llm)

    async def __call__(self, problem: str):
        """
        Implementation of the workflow with validation
        """
        # Run the solver multiple times to generate diverse solutions
        solutions = []
        for i in range(3):
            attempt_context = f"Attempt {i+1}: Solve the problem strictly using Python code for arithmetic in Z_23."
            result = await self.programmer(problem=problem, analysis=attempt_context)
            if 'output' in result:
                solutions.append(result['output'])
            else:
                solutions.append("Error in attempt")

        # Use ScEnsemble to select the most frequent correct answer
        final_result = await self.sc_ensemble(solutions=solutions, problem=problem)
        
        # Validate and correct the output using a custom validator
        # Input: The ensemble result and the original problem
        validation_input = f"Ensemble Result: {final_result['response']}\nOriginal Problem: {problem}"
        validation_response = await self.validator(input=validation_input, instruction=prompt_custom.VALIDATOR_PROMPT)
        
        # Use the validated result for final formatting
        validated_result = validation_response['response']
        
        # Ensure the output format is exactly as required
        formatted_output = validated_result
        if not formatted_output.startswith("FINAL ANSWER:"):
            formatted_output = f"FINAL ANSWER: {formatted_output}"
            
        return formatted_output, self.llm.get_usage_summary()["total_cost"]
