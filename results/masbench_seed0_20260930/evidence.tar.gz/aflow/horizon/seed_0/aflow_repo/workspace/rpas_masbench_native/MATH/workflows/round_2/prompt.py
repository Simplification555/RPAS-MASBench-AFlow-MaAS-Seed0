XXX_PROMPT = """
You are an expert Python programmer solving a complex math problem involving modular arithmetic (modulo 23).
Your task is to write a Python script that solves the problem step-by-step and prints the final answer.

Rules:
1. All arithmetic operations (addition, subtraction, multiplication) must be performed modulo 23.
2. Intermediate results must be reduced to integers between 0 and 22.
3. The script must define variables for every entity mentioned in the problem (e.g., K_Macaw, K_Pheasant).
4. The script must substitute values sequentially based on the dependencies provided in the text.
5. The script must print the final answer in the exact format: FINAL ANSWER: <answer>
6. Do not output any explanation text, only the code and the final printed line.

Problem Description:
{problem}

Write the Python code to solve this problem:
"""