from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_7.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.chain_solver = operator.Custom(self.llm)
        self.format_validator = operator.Custom(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)
        self.programmer = operator.Programmer(self.llm)

    async def __call__(self, problem: str):
        """
        Optimized workflow: Chain solving -> Format Enforcement -> Ensemble
        """
        # Step 1: Solve the chain of problems sequentially to handle dependencies
        chain_result = await self.chain_solver(problem=problem, instruction=prompt_custom.CHAIN_SOLVER_PROMPT)
        
        # Step 2: Validate and reformat the output to ensure strict compliance with extraction rules
        # This fixes issues where the model outputs tuples or misses separators
        validated_result = await self.format_validator(input=chain_result['response'], instruction=prompt_custom.FORMAT_VALIDATOR_PROMPT)
        
        # Step 3: Use ScEnsemble on the validated result (run 3 times for robustness)
        solutions = []
        for i in range(3):
            # Re-run the validation to get variations if needed, or just re-extract
            # Here we re-run the whole chain to get diverse attempts
            temp_chain = await self.chain_solver(problem=problem, instruction=prompt_custom.CHAIN_SOLVER_PROMPT)
            temp_validated = await self.format_validator(input=temp_chain['response'], instruction=prompt_custom.FORMAT_VALIDATOR_PROMPT)
            solutions.append(temp_validated['response'])

        final_result = await self.sc_ensemble(solutions=solutions, problem=problem)
        
        return final_result['response'], self.llm.get_usage_summary()["total_cost"]
