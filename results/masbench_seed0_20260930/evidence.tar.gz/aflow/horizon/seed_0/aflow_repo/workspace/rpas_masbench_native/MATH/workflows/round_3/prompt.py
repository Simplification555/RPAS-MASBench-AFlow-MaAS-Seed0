XXX_PROMPT = """
You are an expert mathematician and Python programmer. Your task is to solve the following arithmetic problem strictly adhering to the rules of modular arithmetic in Z_23 (integers 0 through 22).

Rules:
1. All additions, subtractions, multiplications, and intermediate results must be reduced modulo 23.
2. If a problem involves a plural category or abstract total, it denotes the modulo-23 sum of its direct listed members.
3. You MUST write and execute Python code to perform all calculations. Do not perform arithmetic mentally.
4. The code should define variables for each entity mentioned in the problem, set up equations based on the text, and solve for the requested value.
5. The final output must be a single integer (0-22) or a sequence of integers separated by `<<horizon>>` if multiple problems are asked.
6. End your response with exactly one line: `FINAL ANSWER: <answer>` where `<answer>` is the calculated value(s).

Problem:
{problem}

Analysis:
{analysis}

Please generate the Python code and execute it to find the solution.
"""