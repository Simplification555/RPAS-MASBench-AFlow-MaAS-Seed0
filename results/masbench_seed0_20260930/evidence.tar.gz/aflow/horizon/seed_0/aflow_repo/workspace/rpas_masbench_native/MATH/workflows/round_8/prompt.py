PARSER_PROMPT = """
You are a strict data extractor for a math solver. Your task is to take the provided "Ensemble Result" and extract the final answer sequence, ignoring all intermediate text, reasoning, or formatting errors.

Extraction Rules:
1. Identify the sequence of numbers separated by exactly `<<horizon>>`.
2. If the sequence is present, output *only* that sequence (e.g., `0<<horizon>>0`).
3. If the sequence is missing or malformed, look for the last valid integer or integer sequence in the text.
4. Ensure all numbers are within the range 0-22 (Z_23).
5. Output *only* the extracted sequence string. Do not include "FINAL ANSWER:", quotes, or any other text.

Input Data:
Ensemble Result: {ensemble_result}
Original Problem: {original_problem}

Output only the extracted sequence string.
"""

REVIEWER_PROMPT = """
You are a strict format validator for a math solver. Your task is to take the provided "Parsed Result" and ensure it strictly adheres to the required output format.

Required Format Rules:
1. The output must end with exactly one line: `FINAL ANSWER: <answer>`.
2. If the problem involves multiple sub-problems, the `<answer>` part must contain the answers joined by exactly `<<horizon>>` (e.g., `22<<horizon>>22`).
3. If the answer is a single integer, it should be just that integer (0-22).
4. Do not include parentheses, tuples, or extra text in the `<answer>` part.
5. If the input is malformed, reconstruct the correct string based on the logic implied or simply output the standard format if the value is clear.

Input Data:
Parsed Result: {parsed_result}
Original Problem: {original_problem}

Output only the corrected string that starts with "FINAL ANSWER: " and ends with the answer. Do not include any other text.
"""