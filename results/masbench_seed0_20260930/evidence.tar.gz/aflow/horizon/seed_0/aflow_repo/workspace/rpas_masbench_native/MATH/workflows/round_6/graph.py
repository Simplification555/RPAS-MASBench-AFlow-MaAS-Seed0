from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_6.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.programmer = operator.Programmer(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)
        self.parser = operator.Custom(self.llm)
        self.formatter = operator.Custom(self.llm)

    async def __call__(self, problem: str):
        """
        Implementation of the workflow with validation and parsing
        """
        # Run the solver multiple times to generate diverse solutions
        solutions = []
        for i in range(3):
            attempt_context = f"Attempt {i+1}: Solve the problem strictly using Python code for arithmetic in Z_23."
            result = await self.programmer(problem=problem, analysis=attempt_context)
            if 'output' in result:
                solutions.append(result['output'])
            else:
                solutions.append("Error in attempt")

        # Use ScEnsemble to select the most frequent correct answer
        ensemble_result = await self.sc_ensemble(solutions=solutions, problem=problem)
        
        # Step 1: Parse the ensemble result to extract the clean answer string
        # Input: The raw ensemble response
        parse_input = f"Raw Ensemble Response: {ensemble_result['response']}"
        parsed_response = await self.parser(input=parse_input, instruction=prompt_custom.PARSER_PROMPT)
        
        # Step 2: Format the parsed answer to ensure it starts with "FINAL ANSWER: "
        # Input: The clean parsed answer
        format_input = f"Parsed Answer: {parsed_response['response']}"
        formatted_output = await self.formatter(input=format_input, instruction=prompt_custom.FORMATTER_PROMPT)
        
        return formatted_output, self.llm.get_usage_summary()["total_cost"]
