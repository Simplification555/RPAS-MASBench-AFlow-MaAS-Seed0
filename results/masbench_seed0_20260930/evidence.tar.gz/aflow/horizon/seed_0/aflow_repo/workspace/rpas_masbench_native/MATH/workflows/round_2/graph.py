from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_2.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.programmer = operator.Programmer(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)

    async def __call__(self, problem: str):
        """
        Implementation of the workflow
        """
        # Step 1: Generate multiple independent solutions using the Programmer operator
        # We run the solver 3 times to ensure robustness against reasoning errors
        solutions = []
        for i in range(3):
            # Pass the problem directly to the programmer
            result = await self.programmer(problem=problem)
            # Extract the final answer from the code execution output
            # The programmer returns a dict with 'output' containing the final answer
            if 'output' in result:
                solutions.append(result['output'])
            else:
                # Fallback if code execution fails, try to extract from text
                solutions.append(result.get('output', ''))

        # Step 2: Use ScEnsemble to select the most frequent solution
        # This handles cases where one of the 3 runs might hallucinate
        final_result = await self.sc_ensemble(solutions=solutions, problem=problem)
        
        return final_result['response'], self.llm.get_usage_summary()["total_cost"]
