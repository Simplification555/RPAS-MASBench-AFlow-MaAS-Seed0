CHAIN_SOLVER_PROMPT = """You are an expert solver for a multi-step math problem set involving modular arithmetic (modulo 23).
Your task is to solve the provided problems sequentially, respecting dependencies between them.
Rules:
1. Every quantity is in Z_23. Reduce all additions, subtractions, multiplications, and intermediate results modulo 23 to an integer from 0 through 22.
2. If a problem depends on a previous answer, use that exact value.
3. If there are multiple answers, join them using exactly `<<horizon>>` with no omitted items or reordering.
4. Do not output any explanation text, code, or tuples. Only output the final answers in the specific format below.

Problem Set:
{problem}

Output Format:
FINAL ANSWER: <answer1><<horizon>><answer2>...
"""

FORMAT_VALIDATOR_PROMPT = """You are a strict format validator.
Input text: {input}
Task: Ensure the output strictly follows the pattern: "FINAL ANSWER: <values separated by <<horizon>>>".
If the input contains tuples like (a, b), convert them to a<<horizon>>b.
If the input is missing the "FINAL ANSWER: " prefix, add it.
If the input is missing separators, insert <<horizon>> between values.
Return ONLY the corrected string.
"""