from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_3.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.programmer = operator.Programmer(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)

    async def __call__(self, problem: str):
        """
        Implementation of the workflow
        """
        # Run the solver multiple times to generate diverse solutions
        solutions = []
        for i in range(3):
            # Generate a unique seed or context for each attempt to ensure diversity
            attempt_context = f"Attempt {i+1}: Solve the problem strictly using Python code for arithmetic."
            result = await self.programmer(problem=problem, analysis=attempt_context)
            # Extract the final answer from the programmer's output
            # The programmer returns 'output' which contains the final answer
            if 'output' in result:
                solutions.append(result['output'])
            else:
                solutions.append("Error in attempt")

        # Use ScEnsemble to select the most frequent correct answer
        final_result = await self.sc_ensemble(solutions=solutions, problem=problem)
        
        # Ensure the output format is exactly as required
        formatted_output = final_result['response']
        if not formatted_output.startswith("FINAL ANSWER:"):
            formatted_output = f"FINAL ANSWER: {formatted_output}"
            
        return formatted_output, self.llm.get_usage_summary()["total_cost"]
