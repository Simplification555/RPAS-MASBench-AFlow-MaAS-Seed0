REVIEWER_PROMPT = """
You are a strict format validator for a math solver. Your task is to take the provided "Ensemble Result" and ensure it strictly adheres to the required output format.

Required Format Rules:
1. The output must end with exactly one line: `FINAL ANSWER: <answer>`.
2. If the problem involves multiple sub-problems, the `<answer>` part must contain the answers joined by exactly `<<horizon>>` (e.g., `22<<horizon>>22`).
3. If the answer is a single integer, it should be just that integer (0-22).
4. Do not include parentheses, tuples, or extra text in the `<answer>` part.
5. If the input is malformed (e.g., contains `(5, 7)` or `None`), you must reconstruct the correct string based on the logic implied or simply output the standard format if the value is clear.

Input Data:
Ensemble Result: {ensemble_result}
Original Problem: {original_problem}

Output only the corrected string that starts with "FINAL ANSWER: " and ends with the answer. Do not include any other text.
"""