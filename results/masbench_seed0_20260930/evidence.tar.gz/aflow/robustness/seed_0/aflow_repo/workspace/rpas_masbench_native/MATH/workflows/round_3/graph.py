from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_3.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.programmer = operator.Programmer(self.llm)

    async def __call__(self, problem: str):
        """
        Implementation of the workflow
        """
        # Step 1: Use Custom to identify magic numbers and set up the algebraic problem
        # The instruction tells the LLM to extract magic numbers and prepare the algebraic relations for the programmer.
        step1_result = await self.custom(
            input=problem, 
            instruction=prompt_custom.MAGIC_NUMBER_EXTRACTOR_PROMPT
        )
        
        # Step 2: Use Programmer to solve the algebraic relations in Z_23
        # Pass the original problem to the programmer to ensure it has all context for calculation.
        algebraic_solution = await self.programmer(problem=problem)
        
        # Step 3: Use Custom again to format the final answer
        # Combine the magic numbers (from step 1) and the algebraic result (from step 2) into the final string.
        final_instruction = f"""
        You have the following information:
        1. Magic Numbers (injected facts): {step1_result['response']}
        2. Algebraic Solution (calculated in Z_23): {algebraic_solution['output']}
        
        Format the final answer as follows:
        - Join all required values (Magic Numbers and Algebraic Result) using exactly `<<horizon>>`.
        - Ensure the order matches the question requirements.
        - End with one separate line `FINAL ANSWER: ANSWER`.
        - ANSWER must contain only the single answer or the ordered separator-delimited answer sequence.
        """
        final_response = await self.custom(
            input=problem + "\n\n" + final_instruction, 
            instruction=prompt_custom.FINAL_FORMATTER_PROMPT
        )
        
        return final_response['response'], self.llm.get_usage_summary()["total_cost"]
