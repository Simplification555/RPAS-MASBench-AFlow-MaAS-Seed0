from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_9.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)
        self.programmer = operator.Programmer(self.llm)

    async def __call__(self, problem: str):
        # Step 1: Extract and Verify Magic Numbers using Custom
        # Focus on "Note: verify..." lines and explicit magic number definitions.
        magic_instruction = prompt_custom.MAGIC_NUMBER_EXTRACTOR_PROMPT
        magic_result = await self.custom(
            input=problem, 
            instruction=magic_instruction
        )
        
        # Step 2: Generate multiple candidates for Magic Numbers to ensure robustness
        # We generate 3 variations of the extraction prompt to use ScEnsemble
        candidates = []
        for i in range(3):
            var_prompt = f"""
            {magic_instruction}
            Focus strictly on lines starting with "Note: verify" or explicit "magic number" definitions.
            Ignore all other text.
            Variation {i+1}: Be extremely precise.
            """
            res = await self.custom(input=problem, instruction=var_prompt)
            candidates.append(res['response'])
        
        # Select the most frequent magic number string using ScEnsemble
        best_magic = await self.sc_ensemble(solutions=candidates, problem=problem)
        
        # Step 3: Solve Algebraic Relations using Programmer
        # Pass the original problem so the programmer sees all algebraic dependencies.
        algebraic_solution = await self.programmer(problem=problem)
        
        # Step 4: Format Final Answer using Custom
        # Combine verified magic numbers and algebraic result.
        final_instruction = f"""
        You are formatting the final answer for a math problem.
        Input Context:
        - Original Problem: {problem}
        - Verified Magic Numbers (Immutable Facts): {best_magic['response']}
        - Calculated Algebraic Result: {algebraic_solution['output']}

        Task:
        1. Identify the specific values requested in the problem (usually listed in the prompt instructions).
        2. Combine these values using the separator `<<horizon>>`.
        3. Ensure the order matches the request exactly.
        4. End the output with one separate line: `FINAL ANSWER: [COMBINED_VALUES]`.
        5. Do NOT use LaTeX boxes (\\boxed{}) or any other symbols.
        6. The line must start with "FINAL ANSWER: ".
        """
        final_response = await self.custom(
            input=problem + "\n\n" + final_instruction, 
            instruction=prompt_custom.FINAL_FORMATTER_PROMPT
        )
        
        return final_response['response'], self.llm.get_usage_summary()["total_cost"]
