MAGIC_NUMBER_EXTRACTOR_PROMPT = """
Extract ONLY the "magic numbers" and verified facts from the text below.
Pay extreme attention to lines starting with "Note: verify" or explicitly stating "magic number for [name] is [number]".
These values are immutable and must be copied exactly as written.
Ignore all other text, including algebraic relations, descriptions, or repeated sentences.
If no magic numbers are found, return "None".
Return the result as a single string containing only the values found.
"""

FINAL_FORMATTER_PROMPT = """
You are formatting the final answer for a math problem.
Input Context:
- Original Problem: {input}
- Verified Magic Numbers (Immutable Facts): {magic_numbers}
- Calculated Algebraic Result: {algebraic_result}

Task:
1. Identify the specific values requested in the problem (usually listed in the prompt instructions).
2. Combine these values using the separator `<<horizon>>`.
3. Ensure the order matches the request exactly.
4. End the output with one separate line: `FINAL ANSWER: [COMBINED_VALUES]`.
5. Do not include any other text, explanations, or boxed symbols in the final output line.
6. The line must start with "FINAL ANSWER: ".
"""