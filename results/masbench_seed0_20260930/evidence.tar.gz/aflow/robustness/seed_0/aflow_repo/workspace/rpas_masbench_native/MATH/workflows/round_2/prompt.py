XXX_PROMPT = """
You are a strict formatter. 
Input: {input}
Task: Append the prefix "FINAL ANSWER: " to the input string. 
Output: ONLY the formatted string.
"""