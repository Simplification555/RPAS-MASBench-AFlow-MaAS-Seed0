from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_4.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)
        self.programmer = operator.Programmer(self.llm)

    async def __call__(self, problem: str):
        """
        Optimized workflow with ensemble voting and strict magic number verification
        """
        # Step 1: Extract Magic Numbers and Verify against explicit "Note: verify" instructions
        # Concatenate problem with verification instructions to ensure LLM sees the overrides
        verification_instruction = f"""
        Extract ONLY the "magic numbers" (explicitly injected facts) and specific values mentioned in "Note: verify..." sections.
        If a value is explicitly stated in a "Note: verify..." section, use that EXACT value.
        Ignore all other text, including algebraic relations, descriptions, or repeated sentences.
        Return the result as a single string of key-value pairs or just the values if context is clear.
        """
        step1_result = await self.custom(
            input=problem + "\n\n" + verification_instruction, 
            instruction=prompt_custom.MAGIC_NUMBER_EXTRACTOR_PROMPT
        )
        
        # Step 2: Generate multiple algebraic solution paths using ScEnsemble
        # Create varied prompts to force different reasoning paths for the algebraic part
        ensemble_prompts = [
            "Solve the algebraic relations in Z_23 to find the requested values. Show the calculation steps.",
            "Calculate the values defined by algebraic relations in Z_23. Focus on the final numerical result.",
            "Derive the solution for the math problem using modular arithmetic (mod 23). Provide the final numbers."
        ]
        
        solutions_list = []
        for i, p in enumerate(ensemble_prompts):
            # Pass the original problem to the programmer for each variation
            sol = await self.programmer(problem=problem)
            solutions_list.append(sol['output'])
        
        # Use ScEnsemble to select the most frequent/correct solution
        ensemble_result = await self.sc_ensemble(solutions=solutions_list, problem=problem)
        algebraic_solution = ensemble_result['response']
        
        # Step 3: Final Formatting with strict separator rules
        # Combine verified magic numbers and ensemble algebraic result
        final_instruction = f"""
        You have the following information:
        1. Verified Magic Numbers/Values: {step1_result['response']}
        2. Calculated Algebraic Result (from Ensemble): {algebraic_solution}
        
        Task:
        - Identify the specific values requested in the problem (usually listed in the prompt instructions).
        - Combine these values using the separator `<<horizon>>`.
        - Ensure the order matches the request exactly.
        - End with one separate line `FINAL ANSWER: [COMBINED_VALUES]`.
        - Do not include any other text, explanations, or boxed symbols in the final output line.
        """
        final_response = await self.custom(
            input=problem + "\n\n" + final_instruction, 
            instruction=prompt_custom.FINAL_FORMATTER_PROMPT
        )
        
        return final_response['response'], self.llm.get_usage_summary()["total_cost"]
