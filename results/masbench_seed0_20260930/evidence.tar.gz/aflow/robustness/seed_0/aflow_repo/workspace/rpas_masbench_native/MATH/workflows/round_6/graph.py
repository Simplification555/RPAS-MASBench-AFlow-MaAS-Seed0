from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_6.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)
        self.programmer = operator.Programmer(self.llm)
        self.magic_verifier = operator.MagicNumberVerifier(self.llm)
        self.formatter = operator.FinalAnswerFormatter(self.llm)

    async def __call__(self, problem: str):
        """
        Optimized workflow: Extract Magic Numbers -> Solve Algebra -> Format Final Answer
        """
        # Step 1: Extract and Lock Magic Numbers (Note: verify)
        # This step isolates explicit facts from algebraic relations to prevent modification.
        magic_result = await self.magic_verifier(problem=problem)
        magic_values = magic_result['extracted_values']
        
        # Step 2: Solve Algebraic Relations using Ensemble
        # Generate diverse prompts to ensure robustness in calculation
        algebra_prompts = [
            "Solve the algebraic relations in Z_23. Use the magic numbers: {magic}. Return only the final numbers.",
            "Calculate the values defined by algebraic relations in Z_23. Magic numbers are fixed: {magic}. Show steps briefly.",
            "Derive the solution for the math problem using modular arithmetic (mod 23). Fixed constants: {magic}. Provide final numbers."
        ]
        
        solutions_list = []
        for p in algebra_prompts:
            sol = await self.programmer(problem=problem, analysis=p.format(magic=magic_values))
            solutions_list.append(sol['output'])
        
        # Use ScEnsemble to select the most frequent/correct algebraic solution
        ensemble_result = await self.sc_ensemble(solutions=solutions_list, problem=problem)
        algebraic_solution = ensemble_result['response']
        
        # Step 3: Final Formatting
        # Combine magic numbers and algebraic results, then format strictly for the evaluator
        final_instruction = f"""
        You have the following information:
        1. Verified Magic Numbers (Do not change): {magic_values}
        2. Calculated Algebraic Result (from Ensemble): {algebraic_solution}
        
        Task:
        - Identify the specific values requested in the problem (usually listed in the prompt instructions).
        - Combine these values using the separator `<<horizon>>`.
        - Ensure the order matches the request exactly.
        - End the output with a separate line: `FINAL ANSWER: [COMBINED_VALUES]`.
        - Do NOT include \\boxed{} or any other text in the final line.
        """
        final_response = await self.formatter(
            input=problem + "\n\n" + final_instruction, 
            magic_numbers=magic_values,
            algebraic_result=algebraic_solution
        )
        
        return final_response['response'], self.llm.get_usage_summary()["total_cost"]
