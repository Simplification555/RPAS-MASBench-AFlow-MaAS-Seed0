from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_2.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.programmer = operator.Programmer(self.llm)

    async def __call__(self, problem: str):
        """
        Implementation of the workflow
        """
        # Step 1: Use Programmer to solve the math problem via code execution
        # This handles the Z_23 arithmetic and dependency resolution accurately
        code_result = await self.programmer(problem=problem, analysis="Solve the arithmetic relations in Z_23 and extract the final answer.")
        
        # Step 2: Use Custom to format the output exactly as required (FINAL ANSWER: ...)
        # We pass the code result's output to ensure the final string is correct
        final_response = await self.custom(
            input=code_result['output'], 
            instruction="Format the provided answer string exactly as: FINAL ANSWER: <answer>. Do not add any other text."
        )
        
        return final_response['response'], self.llm.get_usage_summary()["total_cost"]
