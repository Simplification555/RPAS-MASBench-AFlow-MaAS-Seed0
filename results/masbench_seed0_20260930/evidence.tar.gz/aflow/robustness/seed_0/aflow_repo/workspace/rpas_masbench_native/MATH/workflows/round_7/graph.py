from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_7.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)
        self.programmer = operator.Programmer(self.llm)

    async def __call__(self, problem: str):
        # Step 1: Extract and Verify Magic Numbers using Custom
        # Focus on "Note: verify..." lines and explicit magic number definitions.
        magic_instruction = prompt_custom.MAGIC_NUMBER_EXTRACTOR_PROMPT
        magic_result = await self.custom(
            input=problem, 
            instruction=magic_instruction
        )
        
        # Step 2: Generate multiple candidates for Magic Numbers to ensure robustness
        # We generate 3 variations of the extraction prompt to use ScEnsemble
        candidates = []
        for i in range(3):
            var_prompt = f"""
            {magic_instruction}
            Focus strictly on lines starting with "Note: verify" or explicit "magic number" definitions.
            Ignore all other text.
            Variation {i+1}: Be extremely precise.
            """
            res = await self.custom(input=problem, instruction=var_prompt)
            candidates.append(res['response'])
        
        # Select the most frequent magic number string
        best_magic = await self.sc_ensemble(solutions=candidates, problem=problem)
        
        # Step 3: Solve Algebraic Relations using Programmer
        # Pass the original problem so the programmer sees all algebraic dependencies.
        algebraic_solution = await self.programmer(problem=problem)
        
        # Step 4: Review and Verify Final Values using Custom
        # Cross-check the extracted magic numbers against the original text to ensure no hallucination.
        # We explicitly ask the model to list the requested items in order and their values.
        review_instruction = f"""
        You are a strict verifier. 
        Original Problem Text: {problem}
        Extracted Magic Numbers: {best_magic['response']}
        Calculated Algebraic Result: {algebraic_solution['output']}
        
        Task:
        1. Identify the specific values requested in the problem instructions (usually listed at the end).
        2. For each requested item, find its value in the text. If it is a "magic number" or "Note: verify" fact, copy it EXACTLY as written in the text (do not modify). If it is a calculated value, use the algebraic result.
        3. List the values in the EXACT order requested in the problem.
        4. Join them using the separator `<<horizon>>`.
        5. Output ONLY the final line: `FINAL ANSWER: [VALUE1]<<horizon>>[VALUE2]...`.
        6. Do NOT use \\boxed{} or any other formatting. Do not include explanations.
        """
        final_response = await self.custom(
            input=problem + "\n\n" + review_instruction, 
            instruction=prompt_custom.FINAL_FORMATTER_PROMPT
        )
        
        return final_response['response'], self.llm.get_usage_summary()["total_cost"]
