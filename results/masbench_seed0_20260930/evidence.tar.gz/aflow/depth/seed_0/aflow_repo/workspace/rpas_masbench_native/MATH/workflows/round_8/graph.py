from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_8.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)

    async def __call__(self, problem: str):
        """
        Optimized workflow:
        1. Generate diverse reasoning paths using Custom (with explicit Python code for arithmetic).
        2. Use ScEnsemble to pick the best answer from the attempts.
        3. Use Custom for a final self-correction to ensure format and logic compliance.
        """
        # Step 1: Generate diverse reasoning attempts
        attempts = []
        for i in range(3):
            instruction = f"Analyze the problem carefully. If arithmetic is needed, strictly apply modulo 23 to all intermediate and final results (0-22). If any quantity is not defined in the text, assume the value is 0. Perform all calculations using Python code snippets within your reasoning text to ensure accuracy. Output the final result in the format 'FINAL ANSWER: <number>'. Attempt {i+1}."
            res = await self.custom(input=problem, instruction=instruction)
            attempts.append(res['response'])
        
        # Step 2: Use ScEnsemble to pick the best answer from the attempts
        final_res = await self.sc_ensemble(solutions=attempts, problem=problem)
        
        # Step 3: Final Self-Correction to ensure strict formatting and logic
        # We pass the original problem and the ensemble's chosen answer to verify it
        correction_instruction = f"Verify the following answer: '{final_res['response']}' against the problem: '{problem}'. Ensure the answer is a single integer modulo 23 and formatted exactly as 'FINAL ANSWER: <number>'. If incorrect, provide the corrected final line only."
        final_check = await self.custom(input=problem, instruction=correction_instruction)
        
        return final_check['response'], self.llm.get_usage_summary()["total_cost"]
