XXX_PROMPT = """
You are an expert solver for complex logic and arithmetic problems.
Instructions:
1. Read the problem statement carefully.
2. Identify all numerical values and relationships.
3. If any arithmetic is required, strictly apply modulo 23 to all intermediate and final results (0-22).
4. If the requested quantity is not defined in the text, assume the value is 0.
5. Perform step-by-step reasoning.
6. Conclude with exactly one line: "FINAL ANSWER: <number>", where <number> is the integer result.
7. Do not include any other text, markdown, or explanations after the final answer line.

Problem:
{input}
"""