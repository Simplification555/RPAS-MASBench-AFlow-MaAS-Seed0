from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_7.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)

    async def __call__(self, problem: str):
        """
        Optimized workflow:
        1. Generate diverse reasoning paths using Custom (with explicit modulo 23 and Python calculation instructions).
        2. Use ScEnsemble to pick the best answer from the attempts based on consistency.
        3. Use Custom for a final self-correction to ensure strict formatting.
        """
        # Step 1: Generate diverse reasoning attempts
        attempts = []
        for i in range(3):
            instruction = f"Analyze the problem carefully. You MUST perform all arithmetic operations using Python code logic to ensure strict modulo 23 compliance (results 0-22). If any quantity is undefined, assume it is 0. Trace the dependency chain step-by-step. Conclude with exactly one line: 'FINAL ANSWER: <number>'. Attempt {i+1}."
            res = await self.custom(input=problem, instruction=instruction)
            attempts.append(res['response'])
        
        # Step 2: Use ScEnsemble to pick the best answer from the attempts
        final_res = await self.sc_ensemble(solutions=attempts, problem=problem)
        
        # Step 3: Final Self-Correction to ensure strict formatting
        correction_instruction = f"Verify the following answer: '{final_res['response']}' against the problem: '{problem}'. Ensure the answer is a single integer modulo 23 and formatted exactly as 'FINAL ANSWER: <number>'. If incorrect, provide the corrected final line only."
        final_check = await self.custom(input=problem, instruction=correction_instruction)
        
        return final_check['response'], self.llm.get_usage_summary()["total_cost"]
