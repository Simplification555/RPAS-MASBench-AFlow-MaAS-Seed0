from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_9.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)
        self.programmer = operator.Programmer(self.llm)

    async def __call__(self, problem: str):
        """
        Optimized workflow:
        1. Generate 3 diverse reasoning paths using Custom.
        2. Use ScEnsemble to pick the best answer from the attempts.
        3. Use Programmer to execute the logic deterministically for the final answer.
        4. Use Custom for a final self-correction to ensure strict formatting.
        """
        # Step 1: Generate diverse reasoning attempts
        attempts = []
        for i in range(3):
            instruction = f"Analyze the problem carefully. If arithmetic is needed, ensure all results are modulo 23. Output the final result in the format 'FINAL ANSWER: <number>'. Attempt {i+1}."
            res = await self.custom(input=problem, instruction=instruction)
            attempts.append(res['response'])
        
        # Step 2: Use ScEnsemble to pick the best answer from the attempts
        final_res = await self.sc_ensemble(solutions=attempts, problem=problem)
        
        # Step 3: Use Programmer to execute the logic deterministically
        # We pass the problem and the ensemble's chosen answer to verify and re-calculate if needed
        programmer_input = f"Problem: {problem}\nTarget Answer to Verify: {final_res['response']}\nTask: Re-calculate the final answer step-by-step using Python code. Ensure all arithmetic is modulo 23. Return ONLY the final integer result in the variable 'final_answer'."
        prog_result = await self.programmer(problem=programmer_input)
        
        # Step 4: Final Self-Correction to ensure strict formatting
        # We pass the original problem and the programmer's result to verify it
        correction_instruction = f"Verify the following answer: '{prog_result['output']}' against the problem: '{problem}'. Ensure the answer is a single integer modulo 23 and formatted exactly as 'FINAL ANSWER: <number>'. If incorrect, provide the corrected final line only."
        final_check = await self.custom(input=problem, instruction=correction_instruction)
        
        return final_check['response'], self.llm.get_usage_summary()["total_cost"]
