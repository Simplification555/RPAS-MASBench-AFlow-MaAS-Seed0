from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_2.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.programmer = operator.Programmer(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)

    async def __call__(self, problem: str):
        """
        Optimized workflow:
        1. Generate multiple reasoning paths using Custom.
        2. Use Programmer to ensure arithmetic (mod 23) is handled correctly via code.
        3. Use ScEnsemble to select the most consistent final answer.
        """
        # Step 1: Generate diverse reasoning attempts
        attempts = []
        for i in range(3):
            # Inject slight variation in instruction to encourage different reasoning paths
            instruction = f"Analyze the problem carefully. If arithmetic is needed, ensure all results are modulo 23. Output the final result in the format 'FINAL ANSWER: <number>'. Attempt {i+1}."
            res = await self.custom(input=problem, instruction=instruction)
            attempts.append(res['response'])
        
        # Step 2: Use Programmer to verify/execute arithmetic logic if needed, or just as a sanity check
        # We pass the problem and a generic analysis to ensure code execution happens for math
        code_res = await self.programmer(problem=problem, analysis="Perform all arithmetic operations modulo 23.")
        
        # Step 3: Use ScEnsemble to pick the best answer from the attempts
        # The ensemble method will look for the most frequent 'FINAL ANSWER: X' pattern
        final_res = await self.sc_ensemble(solutions=attempts, problem=problem)
        
        return final_res['response'], self.llm.get_usage_summary()["total_cost"]
