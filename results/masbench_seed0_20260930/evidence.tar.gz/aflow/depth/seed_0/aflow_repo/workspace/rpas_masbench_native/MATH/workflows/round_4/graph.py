from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_4.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.programmer = operator.Programmer(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)

    async def __call__(self, problem: str):
        """
        Optimized workflow:
        1. Use Custom to generate a detailed reasoning trace and identify the final numerical result.
        2. Use Programmer to write and execute Python code that parses the problem, builds the dependency graph, and calculates the result strictly modulo 23.
        3. Use Custom to format the Programmer's output into the strict 'FINAL ANSWER: <number>' format.
        """
        # Step 1: Generate reasoning and extract raw answer
        reasoning_prompt = f"""
        You are an expert solver for complex logic and arithmetic problems (MASBench style).
        Problem: {problem}
        
        Instructions:
        1. Analyze the problem statement carefully.
        2. Identify all numerical values, relationships, and dependencies.
        3. If any arithmetic is required, strictly apply modulo 23 to all intermediate and final results (0-22).
        4. If a requested quantity is not defined in the text, assume the value is 0.
        5. Perform step-by-step reasoning to trace the dependencies.
        6. Conclude with a single line containing ONLY the final number, e.g., "17". Do not include "FINAL ANSWER:" or any other text in this step.
        """
        res = await self.custom(input=problem, instruction=reasoning_prompt)
        raw_answer = res['response'].strip()
        
        # Step 2: Use Programmer to verify and calculate using Python
        # We pass the problem and the raw answer to the programmer to verify the logic and re-calculate if needed.
        # The programmer will write code to parse the text, build equations, and solve modulo 23.
        code_res = await self.programmer(
            problem=problem, 
            analysis=f"Verify the logic for the problem. The raw extracted answer is '{raw_answer}'. Write Python code to parse the problem text, build the dependency graph, and calculate the final answer strictly modulo 23. The code must output ONLY the final integer result."
        )
        calculated_answer = code_res['output'].strip()
        
        # Step 3: Use Custom to format the final answer strictly
        format_prompt = f"""
        You are a strict formatter.
        Input Problem: {problem}
        Calculated Result: {calculated_answer}
        
        Task:
        Output the final answer in exactly one line with the format: "FINAL ANSWER: <number>"
        Where <number> is the integer result calculated in the previous step.
        Do not include any other text, explanations, or markdown.
        """
        final_res = await self.custom(input=problem, instruction=format_prompt)
        
        return final_res['response'], self.llm.get_usage_summary()["total_cost"]
