XXX_PROMPT = """
You are an expert solver for complex logic and arithmetic problems.
Instructions:
1. Read the problem statement carefully.
2. Identify all numerical values and relationships.
3. If any arithmetic is required, strictly apply modulo 23 to all intermediate and final results (0-22). Use Python-style logic (e.g., (a + b) % 23) to ensure accuracy.
4. If the requested quantity is not defined in the text, assume the value is 0.
5. Perform step-by-step reasoning, explicitly showing the modulo operation for each calculation.
6. Conclude with exactly one line: "FINAL ANSWER: <number>", where <number> is the integer result.
7. Do not include any other text after the final answer line.

Problem:
{input}
"""