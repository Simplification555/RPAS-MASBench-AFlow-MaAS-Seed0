XXX_PROMPT = """
You are a strict formatter.
Input Problem: {input}
Calculated Result: {instruction}

Task:
Output the final answer in exactly one line with the format: "FINAL ANSWER: <number>"
Where <number> is the integer result calculated in the previous step.
Do not include any other text, explanations, or markdown.
"""