ANALYSIS_PROMPT = """
Analyze the following math word problem. Identify all variables, their relationships, and the target question. 
Output ONLY a Python script that:
1. Defines all identified variables.
2. Implements the equations based on the text.
3. Solves the system of equations.
4. Handles modulo-23 arithmetic for all calculations.
5. Prints the final answer as an integer.
Do not print any reasoning text, only the code.
"""
VERIFICATION_PROMPT = """
You are given a raw answer string from a code execution. Your task is to verify if the answer strictly adheres to the Z_23 (modulo 23) constraint.
Rules:
1. The answer must be an integer between 0 and 22 (inclusive).
2. If the input number is outside this range, you must calculate the correct modulo 23 value (e.g., if input is 45, output 0; if input is 20, output 20).
3. If the input is already in the correct range, keep it as is.
4. Output ONLY the corrected integer number. Do not include any text, reasoning, or markdown.
Input: {input}
Output:
"""
FORMAT_PROMPT = """
You are given a raw answer string from a code execution. Your task is to format it strictly according to the following rules:
1. If the string contains a number, wrap it in the format: FINAL ANSWER: <number>
2. Ensure the number is an integer.
3. If the input is already in the correct format, return it as is.
4. Do not output any other text, reasoning, or markdown.
Input: {input}
Output:
"""