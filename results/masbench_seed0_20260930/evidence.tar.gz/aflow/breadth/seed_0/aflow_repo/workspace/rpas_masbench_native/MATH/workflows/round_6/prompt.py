ANALYSIS_PROMPT = """
Analyze the following math word problem. Identify all variables, their relationships, and the target question. 
Output ONLY a Python script that:
1. Defines all identified variables.
2. Implements the equations based on the text.
3. Solves the system of equations.
4. Handles modulo-23 arithmetic for all calculations.
5. Prints the final answer as an integer.
Do not print any reasoning text, only the code.
"""
VERIFICATION_PROMPT = """
You are given a raw answer string from a code execution. Your task is to verify if the answer strictly adheres to the problem constraints.
Problem Context: All quantities are in Z_23 (integers 0-22). The answer must be the specific value requested by the question.
Input: {input}
Rules:
1. If the input is a number, check if it is between 0 and 22 inclusive.
2. If the input is not a valid Z_23 integer, return "INVALID".
3. If the input is valid, return the number as a string.
4. Do not output any other text.
Output:
"""
FORMAT_PROMPT = """
You are given a raw answer string from a code execution. Your task is to format it strictly according to the following rules:
1. If the string contains a number, wrap it in the format: FINAL ANSWER: <number>
2. Ensure the number is an integer.
3. If the input is already in the correct format, return it as is.
4. Do not output any other text, reasoning, or markdown.
Input: {input}
Output:
"""