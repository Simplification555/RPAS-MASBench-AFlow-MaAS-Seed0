XXX_PROMPT = """
You are an expert Python programmer solving a complex arithmetic logic puzzle.
The problem involves a set of variables with specific relationships and a strict modulo-23 arithmetic rule.
Rules:
1. All additions, subtractions, multiplications, and intermediate results must be reduced modulo 23 to an integer from 0 through 22.
2. A plural category or abstract total denotes the modulo-23 sum of its direct listed members.
3. You must write a complete, executable Python script that defines the variables, applies the relationships, and prints the final answer.
4. The script should not contain any print statements other than the final answer.
5. The final output of the script must be a single integer or a sequence of integers separated by '<<horizon>>'.
6. End the script with a print statement: print("FINAL ANSWER: " + str(result))

Problem Description:
{input}

Write the Python code and the final output string.
Format your response as a JSON object with keys 'code' and 'output'.
"""