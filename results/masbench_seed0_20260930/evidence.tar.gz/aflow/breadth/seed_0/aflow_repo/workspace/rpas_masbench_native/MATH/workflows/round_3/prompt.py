ANALYSIS_PROMPT = """
Analyze the following math word problem. Identify all variables, their relationships, and the target question. 
Output ONLY a Python script that:
1. Defines all identified variables.
2. Implements the equations based on the text.
3. Solves the system of equations.
4. Handles modulo-23 arithmetic for all calculations.
5. Prints the final answer as an integer.
Do not print any reasoning text, only the code.
"""