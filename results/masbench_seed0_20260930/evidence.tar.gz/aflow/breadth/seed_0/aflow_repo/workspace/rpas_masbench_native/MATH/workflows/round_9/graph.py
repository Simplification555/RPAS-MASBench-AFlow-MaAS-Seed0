from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_9.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.programmer = operator.Programmer(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)

    async def __call__(self, problem: str):
        """
        Implementation of the workflow
        """
        # Step 1: Extract dependencies and target variable explicitly
        # This isolates the logic to find "How many X does Y have?" and list all equations.
        deps = await self.custom(
            input=problem, 
            instruction=prompt_custom.DEPENDENCY_EXTRACT_PROMPT
        )
        
        # Step 2: Generate and execute Python code based on extracted dependencies
        code_result = await self.programmer(problem=problem, analysis=deps['response'])
        
        # Step 3: Run ensemble on the code execution results for robustness
        solutions_list = []
        for _ in range(3):
            res = await self.programmer(problem=problem, analysis=deps['response'])
            solutions_list.append(res['output'])
            
        final_result = await self.sc_ensemble(solutions=solutions_list, problem=problem)
        
        # Step 4: Verify the result against Z_23 constraints AND formatting rules
        # This catches calculation errors and ensures the output matches the required "FINAL ANSWER: X" or "X<<horizon>>Y" format.
        verified_result = await self.custom(
            input=final_result['response'], 
            instruction=prompt_custom.VERIFICATION_PROMPT
        )
        
        # Step 5: Final strict formatting pass to guarantee extraction compatibility
        formatted_answer = await self.custom(
            input=verified_result['response'], 
            instruction=prompt_custom.FORMAT_PROMPT
        )
        
        return formatted_answer['response'], self.llm.get_usage_summary()["total_cost"]
