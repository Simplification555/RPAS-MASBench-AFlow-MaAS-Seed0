from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_3.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.programmer = operator.Programmer(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)

    async def __call__(self, problem: str):
        """
        Implementation of the workflow
        """
        # Step 1: Analyze problem and extract dependencies/variables
        analysis = await self.custom(input=problem, instruction=prompt_custom.ANALYSIS_PROMPT)
        
        # Step 2: Generate and execute Python code to solve the math problem
        # Pass the original problem and the analysis to the programmer
        code_result = await self.programmer(problem=problem, analysis=analysis['response'])
        
        # Step 3: Run ensemble on the code execution results for robustness
        # We generate multiple variations of the code execution by slightly perturbing the input or re-running
        # Since Programmer returns a dict with 'output', we collect these outputs.
        # To simulate ensemble without complex loops in graph (keeping complexity low), 
        # we rely on the internal robustness of the operator or a simple re-run if available.
        # However, strictly following the operator interface:
        # We will assume the operator handles the execution. If we need explicit ensemble:
        solutions = [code_result['output']]
        
        # Optional: Re-run with slight variation if the operator supports it, or just use the result.
        # Given the constraint to not over-complicate, we use the result directly if ensemble isn't strictly 
        # triggered by a loop in the graph. But to follow the "ScEnsemble" usage:
        # Let's assume we can call programmer again or the operator handles it. 
        # For this specific optimization, we will use the ScEnsemble operator on a list of generated solutions.
        # We generate 3 solutions by calling the programmer 3 times (simulated via loop if allowed, 
        # but here we assume the operator might return a list or we call it once and pass to ensemble if it supports it).
        # Actually, the operator description says `sc_ensemble(solutions: List[str])`.
        # So we need a list of strings.
        
        # Let's refine: Call Programmer 3 times to get 3 outputs.
        # Note: In a real graph, we might use a loop. Here we simulate the intent by calling it once 
        # and assuming the operator or a hidden mechanism provides diversity, OR we call it 3 times.
        # To strictly adhere to "no extensive modifications" and "complexity < 10", we will call it once 
        # and assume the 'Programmer' operator itself is robust, OR we call it 3 times if the graph allows.
        # Let's try to call it 3 times to feed ScEnsemble.
        
        solutions_list = []
        for _ in range(3):
            res = await self.programmer(problem=problem, analysis=analysis['response'])
            solutions_list.append(res['output'])
            
        final_result = await self.sc_ensemble(solutions=solutions_list, problem=problem)
        
        return final_result['response'], self.llm.get_usage_summary()["total_cost"]
