from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_8.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.programmer = operator.Programmer(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)

    async def __call__(self, problem: str):
        """
        Implementation of the workflow with Self-Consistency
        """
        # Step 1: Analyze problem and extract dependencies/variables
        analysis = await self.custom(input=problem, instruction=prompt_custom.ANALYSIS_PROMPT)
        
        # Step 2: Generate multiple independent code solutions (Self-Consistency)
        solutions_list = []
        for _ in range(3):
            res = await self.programmer(problem=problem, analysis=analysis['response'])
            solutions_list.append(res['output'])
            
        # Step 3: Select the most frequent solution using ScEnsemble
        final_result = await self.sc_ensemble(solutions=solutions_list, problem=problem)
        
        # Step 4: Verify the result against Z_23 constraints BEFORE formatting
        verified_result = await self.custom(
            input=final_result['response'], 
            instruction=prompt_custom.VERIFICATION_PROMPT
        )
        
        # Step 5: Format and Verify the final answer to ensure strict compliance with "FINAL ANSWER: X"
        formatted_answer = await self.custom(
            input=verified_result['response'], 
            instruction=prompt_custom.FORMAT_PROMPT
        )
        
        return formatted_answer['response'], self.llm.get_usage_summary()["total_cost"]
