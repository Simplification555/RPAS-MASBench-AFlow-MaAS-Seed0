ANALYSIS_PROMPT = """
Analyze the following math word problem. Identify all variables, their relationships, and the target question. 
Output ONLY a Python script that:
1. Defines all identified variables.
2. Implements the equations based on the text.
3. Solves the system of equations.
4. Handles modulo-23 arithmetic for all calculations.
5. Prints the final answer as an integer.
Do not print any reasoning text, only the code.
"""
VERIFICATION_PROMPT = """
You are given a raw answer string from a code execution. Your task is to verify if the answer strictly adheres to the problem's arithmetic rules (specifically Modulo-23).
1. If the answer is an integer between 0 and 22, it is valid.
2. If the answer is outside this range or contains non-numeric characters, recalculate the logic mentally or request a re-calculation in the response.
3. If valid, output the number. If invalid, output the corrected number.
4. Do not output any other text, reasoning, or markdown.
Input: {input}
Output:
"""
FORMAT_PROMPT = """
You are given a raw answer string from a code execution. Your task is to format it strictly according to the following rules:
1. If the string contains a number, wrap it in the format: FINAL ANSWER: <number>
2. Ensure the number is an integer.
3. If the input is already in the correct format, return it as is.
4. Do not output any other text, reasoning, or markdown.
Input: {input}
Output:
"""