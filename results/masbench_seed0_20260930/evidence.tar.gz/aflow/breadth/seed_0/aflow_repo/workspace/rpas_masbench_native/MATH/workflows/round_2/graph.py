from typing import Literal
import workspace.rpas_masbench_native.MATH.workflows.template.operator as operator
import workspace.rpas_masbench_native.MATH.workflows.round_2.prompt as prompt_custom
from scripts.async_llm import create_llm_instance


from scripts.evaluator import DatasetType

class Workflow:
    def __init__(
        self,
        name: str,
        llm_config,
        dataset: DatasetType,
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.llm = create_llm_instance(llm_config)
        self.custom = operator.Custom(self.llm)
        self.programmer = operator.Programmer(self.llm)
        self.sc_ensemble = operator.ScEnsemble(self.llm)

    async def __call__(self, problem: str):
        """
        Implementation of the workflow
        """
        # Step 1: Analyze dependencies and generate a Python script to solve the problem
        # The programmer will handle the modulo-23 arithmetic and variable tracing
        code, output = await self.programmer(problem=problem, analysis="Analyze the dependency graph and write a Python script to solve the arithmetic problem using modulo 23.")
        
        # Step 2: Execute the generated code to get the solution
        # We use the custom method to run the code safely and extract the result
        # Note: The programmer returns 'code' and 'output'. We assume 'output' contains the result or we run the code.
        # To be safe and follow the operator description: programmer returns dict with 'code' and 'output'.
        # We will use the 'output' if it contains the final answer, otherwise we might need to re-run.
        # However, the operator description says "returns the solution based on...". Let's assume 'output' is the solution.
        # But to ensure strict format, let's use the custom method to format the final answer if needed, 
        # or rely on the programmer's output if it's clean.
        # Given the error log showed the model struggling with the chain, let's force a code execution path.
        # We will pass the code to a custom execution step if the operator doesn't execute it automatically.
        # Re-reading operator description: "Automatically writes, executes Python code, and returns the solution".
        # So 'output' should be the solution.
        
        solution = output
        
        # Step 3: Use ScEnsemble to ensure consistency if multiple solutions were generated (though programmer returns one)
        # We can generate multiple variations of the problem analysis to get multiple solutions for ensemble.
        # Let's generate 3 variations of the analysis prompt to get 3 solutions.
        variations = [
            "Analyze the dependency graph and write a Python script to solve the arithmetic problem using modulo 23.",
            "Trace the variables step-by-step and write a Python script to calculate the final answer using modulo 23.",
            "Identify all mathematical relationships and write a Python script to compute the result modulo 23."
        ]
        
        solutions_list = []
        for var_prompt in variations:
            code, out = await self.programmer(problem=problem, analysis=var_prompt)
            solutions_list.append(out)
            
        # Step 4: Ensemble the solutions
        final_solution = await self.sc_ensemble(solutions=solutions_list, problem=problem)
        
        return final_solution['response'], self.llm.get_usage_summary()["total_cost"]
