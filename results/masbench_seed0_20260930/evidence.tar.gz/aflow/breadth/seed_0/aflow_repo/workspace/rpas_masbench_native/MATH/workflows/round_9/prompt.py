DEPENDENCY_EXTRACT_PROMPT = """
Analyze the following math word problem. Your goal is to extract the explicit dependency chain and the target question.
1. Identify the target variable (e.g., "How many Product does Shipt have?").
2. List every equation provided in the text that defines a variable.
3. Do not solve the equations yet. Just list them as "Variable = Expression".
4. Ensure all modulo-23 constraints are noted.
Output ONLY a structured text block containing the target and the list of equations.
Input: {input}
Output:
"""
VERIFICATION_PROMPT = """
You are given a raw answer string from a code execution. Your task is to verify if the answer strictly adheres to the Z_23 (modulo 23) constraint and the specific output format.
Rules:
1. The numeric value(s) must be integers between 0 and 22 (inclusive). If outside, calculate the correct modulo 23 value.
2. If the problem implies multiple answers, they must be joined using exactly `<<horizon>>`.
3. If the input is a single number, ensure it is an integer.
4. If the input is a list of numbers, ensure they are joined with `<<horizon>>`.
5. Output ONLY the corrected and formatted integer sequence (e.g., "5" or "5<<horizon>>14"). Do not include any text, reasoning, or markdown.
Input: {input}
Output:
"""
FORMAT_PROMPT = """
You are given a raw answer string. Your task is to format it strictly according to the following rules:
1. The final output must end with the line: FINAL ANSWER: <value>
2. The <value> must be the integer(s) calculated previously, joined by `<<horizon>>` if multiple.
3. Ensure no extra whitespace or text exists before or after "FINAL ANSWER: ".
4. If the input is already in the correct format, return it as is.
5. Do not output any other text, reasoning, or markdown.
Input: {input}
Output:
"""